/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Carousel } from './carousel.component';

describe('Component: Carousel', () => {
  it('should create an instance', () => {
    let component = new Carousel();
    expect(component).toBeTruthy();
  });
});
