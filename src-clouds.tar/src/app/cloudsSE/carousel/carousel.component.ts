import {Component,ViewEncapsulation} from '@angular/core';
//import {CORE_DIRECTIVES, FORM_DIRECTIVES} from '@angular/common';
//mport {Slide} from './slide.component';
import {SlideShowComponent} from './slideshow.component';
//import {NgbCarouselModule} from '@ng-bootstrap/ng-bootstrap';


/*Angular 2 Carousel - Gallery*/
@Component({
    selector: 'carousel-app',
    templateUrl:'carousel.component.html',
    styleUrls: ['carousel.component.css'],
    //encapsulation: ViewEncapsulation.Emulated
    //styleUrls: ['./bootstrap.css'],
    //encapsulation: ViewEncapsulation.Native
    //directives: [Slide,Carousel, CORE_DIRECTIVES, FORM_DIRECTIVES],
})
export class Carousel  {
    //The time to show the next photo
    private NextPhotoInterval:number = 3000;
    //Looping or not
    private noLoopSlides:boolean = false;
    //Photos
    private slides:Array<any> = [];

    constructor() {
            this.addNewSlide();
    }

    private addNewSlide() {
         this.slides.push(
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide1.jpg',text:'digital transformation'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide2.jpg',text:'digital crossroad'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide3.jpg',text:'digital needs'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide4.jpg',text:'4'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide5.jpg',text:'5'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide6.jpg',text:'6'},
            {image:'http://localhost:4200/app/cloudsSE/carousel/images/Slide7.jpg',text:'7'}

            /*
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car1.jpg',text:'BMW 1'},
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car2.jpg',text:'BMW 2'},
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car3.jpg',text:'BMW 3'},
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car4.jpg',text:'BMW 4'},
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car5.jpg',text:'BMW 5'},
            {image:'http://www.angulartypescript.com/wp-content/uploads/2016/03/car6.jpg',text:'BMW 6'}
            */
        );
    }
}