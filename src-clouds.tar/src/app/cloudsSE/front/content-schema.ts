export interface Content {
  text: string;
  state: string;
}
/*
export class Hero {
    
    constructor(
    public id?: string,
    public name?: string,
    public power?: string,
    public alterEgo?: string
  ) {
    //this.id = id || nextId++;
  }
}
*/