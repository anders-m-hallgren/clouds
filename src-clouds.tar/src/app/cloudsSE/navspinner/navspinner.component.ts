import { Component, ViewEncapsulation} from '@angular/core';

@Component({
    selector: 'navspinner',
    templateUrl: 'navspinner.component.html',
    styleUrls: ['navspinner.component.css'],
    encapsulation: ViewEncapsulation.Emulated
    //animate:[]
})
export class Navspinner {

    ngOnInit() {
    }
}