export { ToolbarDemo } from './toolbar.component';

