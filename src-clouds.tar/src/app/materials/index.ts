export { ToolbarDemo } from './toolbar-demo/toolbar.component';
export { ButtonDemo } from './button-demo/button.component';
export { TabDemo } from './tab-demo/tab.component';
export { SidenavDemo } from './side-navigate/side-navigate.component';
export { ListDemo } from './list-demo/list.component';

