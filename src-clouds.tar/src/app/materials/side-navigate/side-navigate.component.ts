import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'sidenav-demo',
  templateUrl: 'sidenav.html',
  styleUrls: ['sidenav.css'],
})
export class SidenavDemo {}